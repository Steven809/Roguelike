﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LvGenerator : MonoBehaviour {

    public GameObject player;
    public GameObject enemy;
    public int enemyAmount = 10;

    public GameObject[] tiles;
    public GameObject wall;
    public List<Vector3> createdTile;


    public int tileAmount;
    public int tileSize;

    public float chanceUp;
    public float chanceRight;
    public float chanceDown;


    public float waitTime;
    private int tileIndex;

    // wall generations

    public float minY = 9999999;
    public float maxY = 0;
    public float minX = 9999999;
    public float maxX = 0;
    public float xAmount;
    public float yAmount;
    public float extaWallX;
    public float extaWallY;

    // Use this for initialization
    void Start() {

        StartCoroutine(GenerateLevel());

        // UnityEngine.Random.seed = 10; Record seed
    }


    IEnumerator GenerateLevel() {

        for (int i = 0; i < tileAmount; i++)
        {
            float dir = UnityEngine.Random.Range(0f, 1f);
            int tile = UnityEngine.Random.Range(0, tiles.Length);

            CreateTile(tile);
            CallMoveGen(dir);
            

            yield return new WaitForSeconds(waitTime); //slow down the procedure from generating 

            if (i == tileAmount - 1) {

                Finish();
            }
        }

        yield return 0;

    }
    void CallMoveGen(float ranDir)
    {
        if (ranDir < chanceUp)
        {
            MoveGen(0);
        } else if (ranDir < chanceRight)
        {
            MoveGen(1);
        } else if (ranDir < chanceDown)
        {
            MoveGen(2);
        } else
        {
            MoveGen(3);
        }


    }

    void MoveGen(int dir) //generater moving from up,down,left and right
    {
        switch (dir)
        {
            case 0:

                transform.position = new Vector3(transform.position.x, transform.position.y + tileSize, 0);

                break;

            case 1:

                transform.position = new Vector3(transform.position.x + tileSize, transform.position.y, 0);

                break;

            case 2:

                transform.position = new Vector3(transform.position.x, transform.position.y - tileSize, 0);

                break;

            case 3:

                transform.position = new Vector3(transform.position.x - tileSize, transform.position.y, 0);

                break;

        }

    }
    // Update is called once per frame

    void CreateTile(int tileIndex)
    {
        if (!createdTile.Contains(transform.position)) //Get alec help
        {

        }
        GameObject tileObject;

        tileObject = Instantiate(tiles[tileIndex], transform.position, transform.rotation) as GameObject;

        createdTile.Add(tileObject.transform.position); //Get help from Alec
    }
    void Finish() {

        CreateWallValues();
        CreateWalls();
        SpawnObjects();

    }
    void CreateWallValues()
    {
        for (int i = 0; i < createdTile.Count; i++)
        {
            if (createdTile[i].y < minY) {

                minY = createdTile[i].y;

            }
            if (createdTile[i].y > maxY) {

                maxY = createdTile[i].y;
            }
            if (createdTile[i].x < minX)
            {

                minX = createdTile[i].x;

            }
            if (createdTile[i].x > maxX)
            {

                maxX = createdTile[i].x;
            }
            // distance of max and min then divided the tiles plus the extra wall
            xAmount = ((maxX - minX) / tileSize) + extaWallX;
            yAmount = ((maxY - minY) / tileSize) + extaWallY;
        }




    }
    void SpawnObjects()
    {

        for (int i = 0; i < enemyAmount; i++) {

            Instantiate(enemy, createdTile[UnityEngine.Random.Range(0, createdTile.Count)], Quaternion.identity);
        }


    }

    void CreateWalls()
    {
        for (int x = 0; x < xAmount; x++)
        {
            for (int y = 0; y < yAmount; y++)
            {
                if (!createdTile.Contains(new Vector3((minX - (extaWallX * tileSize) / 2) + (x * tileSize), (minY - (extaWallY * tileSize) / 2) + (y * tileSize)))) {

                    Instantiate(wall, new Vector3((minX - (extaWallX * tileSize) / 2) + (x * tileSize), (minY - (extaWallY * tileSize) / 2) + (y * tileSize)), transform.rotation);

                }
            }


        }
    }
        void Update() {

        }

    }
