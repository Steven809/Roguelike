﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class FoodTimer : MonoBehaviour
{
    public int timeLeft = 100;
    public Text countdownText;
    public float hungerSpeed = 5;

    // Use this for initialization
    void Start()
    {
        StartCoroutine("LoseTime");

    }

    // Update is called once per frame
    void Update()
    {
        countdownText.text = ("Hunger: " + timeLeft);
        if (timeLeft <= 0)
        {
            StopCoroutine("LoseTime");
            countdownText.text = "You Starved!";
            //Application.LoadLevel("Gameover");
        }
    }
    IEnumerator LoseTime()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            timeLeft--;
        }
    }
}